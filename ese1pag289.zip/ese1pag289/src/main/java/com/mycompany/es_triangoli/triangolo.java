/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.es_triangoli;

/**
 *
 * @author Asus
 */
public class triangolo {
    private double a;
    private double b;
    private double c;

    public triangolo(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public String tipologia(){
        String tipo="scaleno";
        double ipotenusa=0.0;
        double l1=0.0;
        double l2=0.0;
        if(a==b || b==c){
            if(a==b && b==c){
                tipo="equilatero";
            }else{
                tipo="isoscele";
            }
        }
        
        if(a>b && a>c){
            ipotenusa=a;
            l1=b;
            l2=c;
        }
        if(b>a && b>c){
            ipotenusa=b;
            l1=c;
            l2=a;
        }
        if(c>b && c>a){
            ipotenusa=c;
            l1=b;
            l2=a;
        }
        if((ipotenusa*ipotenusa)==(l1*l1+l2*l2)){
            tipo=tipo+", rettangolo";
        }
        return tipo;
    }
    
    public double perimetro(){
        return a+b+c;
    }
    
    public double area(){
        double s=(a+b+c)/2;
        return Math.sqrt(s*((s-a)*(s-b)*(s-c)));
    }
}
